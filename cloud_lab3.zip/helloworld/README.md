# hello world
 #maven编译测试使用  
 #编译为war包,放到tomat,简单的hello world页面 

 #编译测试  
mvn clean package

 #dokcer自动化构建java web 基于jenkins+maven+nuxus容器  
http://www.cnblogs.com/elvi/p/8884340.html

